//
//  TextFieldEffects.h
//  TextFieldEffects
//
//  Created by Raúl Riera on 05/03/2015.
//  Copyright (c) 2015 Raul Riera. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TextFieldEffects.
FOUNDATION_EXPORT double TextFieldEffectsVersionNumber;

//! Project version string for TextFieldEffects.
FOUNDATION_EXPORT const unsigned char TextFieldEffectsVersionString[];

// In this header, you should import all the open headers of your framework using statements like #import <TextFieldEffects/PublicHeader.h>


